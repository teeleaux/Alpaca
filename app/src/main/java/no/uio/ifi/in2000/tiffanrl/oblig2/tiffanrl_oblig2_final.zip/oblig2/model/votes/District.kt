package no.uio.ifi.in2000.tiffanrl.oblig2.model.votes

enum class District {
    DISTRICT_1,
    DISTRICT_2,
    DISTRICT_3
}