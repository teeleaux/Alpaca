package no.uio.ifi.in2000.tiffanrl.oblig2.ui.theme.home

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import io.ktor.utils.io.errors.IOException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import no.uio.ifi.in2000.tiffanrl.oblig2.data.alpacas.AlpacaPartiesRepository
import no.uio.ifi.in2000.tiffanrl.oblig2.data.alpacas.PartiesRepository
import no.uio.ifi.in2000.tiffanrl.oblig2.data.votes.VotesRepository
import no.uio.ifi.in2000.tiffanrl.oblig2.network.AlpacaAPI
import no.uio.ifi.in2000.tiffanrl.oblig2.ui.theme.AlpacaPartyUIState


class HomeViewModel : ViewModel() {

    val votesRepository: VotesRepository = VotesRepository()
    private val partiesRepository: PartiesRepository = AlpacaPartiesRepository()
    private val _errorState = MutableStateFlow<String?>(null)

    var partiesUIState by mutableStateOf(AlpacaPartyUIState(parties = listOf()))
        private set

    var errorState: StateFlow<String?> = _errorState


    init{
        loadParties()
    }

    private fun loadParties() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
            val parties = partiesRepository.getAlpacaPartiesData()
            partiesUIState = partiesUIState.copy(parties = parties)
        } catch (e: IOException) {
            _errorState.value = "No Internet Connection"
        } catch (e: Exception) {
            _errorState.value = "Bleep bloop error" //handle other errors
        }
            //val parties = partiesRepository.getAlpacaPartiesData()
            //partiesUIState = partiesUIState.copy(parties = parties)
        }

    }
    private fun getData() {
        viewModelScope.launch {
            val listResult = AlpacaAPI.retrofitService.getData()
            partiesUIState = listResult
        }
    }

    fun getDistrictVotes() {
        viewModelScope.launch(Dispatchers.IO){
            var districtVotes by mutableStateOf(listOf(votesRepository.getDistrict1Votes()))
            Log.i("HVM getDistrictVotes call", "${districtVotes[1][1].district}")
        }
    }
}



