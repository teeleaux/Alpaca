package no.uio.ifi.in2000.tiffanrl.oblig2.ui.theme.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import no.uio.ifi.in2000.tiffanrl.oblig2.model.votes.DistrictVotes

data class Vote(val partyId: String, val voteCount: Int)

@Preview
@Composable
fun VoteListPreview() {
    // Display the VoteList component with dummy data
    //VoteList(votes = {})
}

// Define the VoteList composable
@Composable
fun VoteList(votes: List<DistrictVotes>) {
    LazyColumn {
        items(votes) { vote ->
            // Display each vote item
            Row(modifier = Modifier
                .fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.Bottom,
                content = {
                    Text(
                    vote.alpacaPartyId +" " + " " + vote.numberOfVotesForParty,
                    modifier = Modifier
                    )
                }
            )
        }
    }
}