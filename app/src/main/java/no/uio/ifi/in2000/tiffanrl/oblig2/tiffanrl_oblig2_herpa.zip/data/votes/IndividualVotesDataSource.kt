package no.uio.ifi.in2000.tiffanrl.oblig2.data.votes

import android.util.Log
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.request.get
import io.ktor.serialization.gson.gson
import no.uio.ifi.in2000.tiffanrl.oblig2.model.votes.District
import no.uio.ifi.in2000.tiffanrl.oblig2.model.votes.DistrictVotes

class IndividualVotesDataSource(
    private val pathDistrict1:String =
        "https://www.uio.no/studier/emner/matnat/ifi/IN2000/v24/obligatoriske-oppgaver/district1.json",
    private val pathDistrict2:String =
        "https://www.uio.no/studier/emner/matnat/ifi/IN2000/v24/obligatoriske-oppgaver/district2.json"
) {
    var totalNrVotes: Int = 0

    private val client = HttpClient() { //makes HTTP client
        install(ContentNegotiation) { // tool for å lese inn JSON format
            gson() //caller gson tool for getting a JSON response
        }
    }

    // alter to pass a string as parameter
    suspend fun fetchDistrict1Votes(): List<DistrictVotes> {
        val votes: List<DistrictVotes> = client.get(pathDistrict1).body()
        //maybe make a Districts class which holds val districts: List<DistrictVotes>
        totalNrVotes = votes.size

        val jsonString:String = client.get(pathDistrict1).body()
        val votesList = parseJsonToList(jsonString)

        // Group by the second variable and count occurrences — maps incorrectly
        val tallyMap = votesList.groupBy { it.second }.mapValues { it.value.size }


        Log.i("votes IVDS call", "${votes.size}")
        //Log.i("votes groupBy", "${votes.groupBy{it.alpacaPartyId}}")

        //val tallyMap = votes.groupBy { it.alpacaPartyId }.mapValues { it.value.size }

        Log.i("TallyMap values", "${tallyMap.values}")
        Log.i("TallyMap keys", "${tallyMap.keys}")

        return tallyMap.map { (alpacaPartyId, numberOfVotesForParty) ->
            val district = District.DISTRICT_1
            Log.i("TallyMap APID noe her?", alpacaPartyId)
            DistrictVotes(district, alpacaPartyId, numberOfVotesForParty)
        }
    }

    fun parseJsonToList(jsonString: String): List<Pair<String, String>> {
        val gson = Gson()
        val typeToken = object : TypeToken<List<Pair<String, String>>>() {}.type
        return gson.fromJson(jsonString, typeToken)
    }

    suspend fun fetchDistrict2Votes(): List<DistrictVotes> {
        val votes: List<DistrictVotes> = client.get(pathDistrict2).body()

        val tallyMap = votes.groupBy { it.alpacaPartyId }.mapValues { it.value.size }

        return tallyMap.map { (alpacaPartyId, numberOfVotesForParty) ->
            val district = District.DISTRICT_2
            DistrictVotes(district, alpacaPartyId, numberOfVotesForParty)
        }
    }

    /*
    suspend fun fetchDistrictVotes(paths: List<String>): List<List<DistrictVotes>> {
        return paths.mapIndexed { index, path ->
            val votes = client.get<List<Vote>>(path)

            // Group votes by alpacaPartyId and count the occurrences
            val tallyMap = votes.groupBy { it.alpacaPartyId }.mapValues { it.value.size }

            val district = when (index) {
                0 -> District.DISTRICT_1
                1 -> District.DISTRICT_2
                else -> throw IllegalArgumentException("Invalid district index: $index")
            }
            // Create DistrictVotes objects for each district with tallied votes
            tallyMap.map { (alpacaPartyId, numberOfVotesForParty) ->
                DistrictVotes(district, alpacaPartyId, numberOfVotesForParty)
            }
            }*/
    }

/*
      District.entries.map { district ->
                val alpacaPartyID = district.name
                val numberOfVotesForParty = tallyMap.getOrElse(alpacaPartyID) { 0 }
                DistrictVotes(district, alpacaPartyID, numberOfVotesForParty)
    val district1votes: DistrictVotes = client.get(path1).body()
        val district2votes: DistrictVotes = client.get(path2).body()
        val response = client.get(path1)
        Log.i("fetchIndividualDistrictVotes call from DataSource", "response: $response")

        val districtVotesList = mutableListOf<DistrictVotes>()

        val tallyMap= mutableMapOf<String, Int>()

        for (voteList in districtVotesList){
            for ()
        }

        return districtVotesList

 */