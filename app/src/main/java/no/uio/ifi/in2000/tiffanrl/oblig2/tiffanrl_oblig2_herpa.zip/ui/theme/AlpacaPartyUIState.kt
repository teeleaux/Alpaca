package no.uio.ifi.in2000.tiffanrl.oblig2.ui.theme

import no.uio.ifi.in2000.tiffanrl.oblig2.model.alpacas.PartyInfo

data class AlpacaPartyUIState(
    val parties: List<PartyInfo>
) {

}