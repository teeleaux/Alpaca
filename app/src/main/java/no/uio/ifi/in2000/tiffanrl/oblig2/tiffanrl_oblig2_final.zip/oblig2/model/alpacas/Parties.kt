package no.uio.ifi.in2000.tiffanrl.oblig2.model.alpacas

data class Parties(
    val parties: List<PartyInfo>
)