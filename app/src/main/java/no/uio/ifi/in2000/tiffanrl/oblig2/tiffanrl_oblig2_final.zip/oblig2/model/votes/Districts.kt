package no.uio.ifi.in2000.tiffanrl.oblig2.model.votes

data class Districts (
    val districts: List<DistrictVotes>
)